package com.walletapp.dao;

import com.walletapp.bean.CustomerDetails;
import com.walletapp.exception.WalletException;

public interface IWalletDao {
	Long addCustomer(CustomerDetails cd) throws WalletException;
	CustomerDetails getBalance(Long accnum,String pin) throws WalletException; 
	CustomerDetails setDeposit(Long accnum, String pin, String amt) throws WalletException; 
	CustomerDetails getWithdraw(Long accnum, String pin, String amt)throws WalletException;  
	CustomerDetails getFundTransfer(Long accnum, Long oaccnum, String pin, String amt)throws WalletException;  
	 boolean getPrintTransactions(Long accnum, String pin)throws WalletException;  
}
