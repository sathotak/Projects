package org.cap.service;

import java.util.List;
import org.cap.dao.IPilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("pilotService")
public class PilotServiceImpl implements IPilotService {
    @Autowired
    private IPilotDao pilotDao;
	/*@Override
	public void savePilot(Pilot pilot) {
		pilotDao.savePilot(pilot);
		
	}*/
	@Override
	public List<Pilot> getAll() {
				return pilotDao.findAll();
	}
	@Override
	public void delete(Integer pilotId) {
		pilotDao.deleteById(pilotId);
		
	}
	@Override
	public void edit(Pilot pilot1) {
		pilotDao.save(pilot1);
	}
	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return pilotDao.getOne(pilotId);
	}
	
}
