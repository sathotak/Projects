package com.wallet.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.wallet.bean.CustomerDetails;
import com.wallet.bean.TransactionDetails;
import com.wallet.dao.IWalletDAo;
import com.wallet.dao.WalletDAO;
import com.wallet.exception.WalletException;

public class WalletDAOTest {

	       IWalletDAo dao=null;
	       @Before
	       public void setup() {
	              dao=new WalletDAO();
	       }
	       
	       @After
	       public void tearDown() {
	              dao = null;
	       }
	       

	       @Test
	       public void testCreateAccount() {
	              CustomerDetails c = new CustomerDetails();
	              c.setAccountNumber(12345678919L);
	              c.setCustomerName("Prani");
	              c.setMoblieNumber("1234567890");
	              c.setAddress("Pune");
	              c.setBalance(200000);
	              c.setAtmPin("1122");
	              
	              
	              try {
	                     dao.addCustomer(c);
	                     CustomerDetails c1=dao.getBalance(12345678910L,"1125");
	                     assertNotNull(c1);
	              } catch (WalletException e) {
	                     // TODO Auto-generated catch block
	                     System.out.println(e.getMessage());
	              }
	       }

	       @Test
	       public void testShowBalance() {
	              try {
	            	  CustomerDetails c = dao.getBalance(12345678911L,"2345");
	                     assertNotNull(c);
	                     CustomerDetails c1 = dao.getBalance(12345678919L,"2345");
	                     assertNull(c1);
	              } catch (WalletException e) {
	                     // TODO Auto-generated catch block
	                     System.out.println(e.getMessage());
	              }
	       }
	       
	       @Test
	       public void testDepositPositive() throws WalletException {
	    	   CustomerDetails c = new CustomerDetails();
	    	   c.setAccountNumber(12345678911L);
	    	   c.setCustomerName("Ben");
	    	   c.setBalance(2343445.33);
	              assertNotEquals(c, dao.setDeposit(12345678911L,"2345","1000"));
	       }
	       
	       @Test
	       public void testWithdrawPositive() throws WalletException {
	    	   CustomerDetails c = new CustomerDetails();
	    	   c.setAccountNumber(12345678911L);
	    	   c.setCustomerName("Ben");
	    	   c.setBalance(2343445.33);
	           assertNotEquals(c, dao.getWithdraw(12345678911L,"2345","2000"));
	       }
	       
	       @Test
	       public void testFundTransferPositive() throws WalletException {
	    	   CustomerDetails c = new CustomerDetails();
	    	   c.setAccountNumber(12345678911L);
	    	   c.setCustomerName("Ben");
	    	   c.setBalance(2343445.33);
	              assertNotEquals(c, dao.getFundTransfer(12345678910L,12345678911L,"2345","1000"));
	       }
	       @Test
	       public void testPrintTransaction() throws WalletException {
	    	assertFalse(dao.getPrintTransactions(12345678912L,"4556"));
		 
	       }
	       
}   



	