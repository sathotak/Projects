package com.wallet.dao;

import java.util.HashMap;

import com.wallet.bean.CustomerDetails;
import com.wallet.bean.TransactionDetails;
import com.wallet.exception.WalletException;

public interface IWalletDAo {
	Long addCustomer(CustomerDetails cd) throws WalletException;
	CustomerDetails getBalance(Long accnum,String pin) throws WalletException; 
	CustomerDetails setDeposit(Long accnum, String pin, String amt); 
	CustomerDetails getWithdraw(Long accnum, String pin, String amt); 
	CustomerDetails getFundTransfer(Long accnum, Long oaccnum, String pin, String amt); 
	 boolean getPrintTransactions(Long accnum, String pin); 

}
