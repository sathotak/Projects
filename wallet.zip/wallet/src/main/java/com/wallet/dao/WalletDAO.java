package com.wallet.dao;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Optional;

import com.wallet.bean.CustomerDetails;
import com.wallet.bean.TransactionDetails;
import com.wallet.db.CustomerDb;
import com.wallet.exception.WalletException;

public class WalletDAO implements IWalletDAo {
	static HashMap<Long,CustomerDetails>
     customerMap=CustomerDb.getCustomerMap();
	 static HashMap<Integer, TransactionDetails>
     transactionMap=CustomerDb.getTransactionMap();
	
	 int id=0;
	
	@Override
	public Long addCustomer(CustomerDetails cd) throws WalletException {
try {
			
	if(customerMap.size()==0) {
		cd.setAccountNumber(12345678910l);;
	}
	else {
		Optional<Long> accountNumber=customerMap.keySet().stream().max(new Comparator<Long>() {
			@Override
			public int compare(Long x, Long y) {
				return x>y?1:x<y?-1:0;
			}
		});
		Long newAccountNumber=accountNumber.get()+1;
		cd.setAccountNumber(newAccountNumber);;
	}	
	
	customerMap.put(cd.getAccountNumber(),cd);
	return cd.getAccountNumber();
	
}
		catch (Exception ex) {
			throw new WalletException(ex.getMessage());
		}
		
	}
	@Override
	public CustomerDetails getBalance(Long accnum,String pin) throws WalletException {
		try {
			CustomerDetails customer=customerMap.get(accnum);
			
			if(customer==null) {
				throw new WalletException("customer with the account number "+accnum+" Not existed");
			}
			if(customer.getAtmPin().equalsIgnoreCase(pin)) {
			return customer;
			}
			else {
				throw new WalletException("Invalid user");
			}
			}
			catch(WalletException ex) {
				System.out.println(ex.getMessage());
			}
		return null;
			
	}
	@Override
	public CustomerDetails setDeposit(Long accnum, String pin, String amt) {
		try {
			CustomerDetails customer=customerMap.get(accnum);
			
			if(customer==null) {
				throw new WalletException("customer with the account number "+accnum+" Not existed");
			}
			if(customer.getAtmPin().equalsIgnoreCase(pin)) {
			double balance=customer.getBalance() + Double.parseDouble(amt);
			customer.setBalance(balance);
			id++;
			transactionMap.put(id,new TransactionDetails(accnum,"Deposit",Double.parseDouble(amt),LocalDateTime.now()));
			return customer;
			}
			else {
				throw new WalletException("Invalid user");
			}
			}
		catch(WalletException ex) {
			System.out.println(ex.getMessage());
		}
		return null;
			
	}
	@Override
	public CustomerDetails getWithdraw(Long accnum, String pin, String amt) {
		CustomerDetails customer=customerMap.get(accnum);
		try {
					
			if(customer==null) {
				throw new WalletException("customer with the account number "+accnum+" Not existed");
			}
			if(customer.getAtmPin().equalsIgnoreCase(pin)) {
				if(customer.getBalance() <=Double.parseDouble(amt)) {
					System.out.println("Low Balance");
				
				}
				else {
					double balance=customer.getBalance() - Double.parseDouble(amt);
					customer.setBalance(balance);
					id++;
					transactionMap.put(id,new TransactionDetails(accnum,"Withdraw",Double.parseDouble(amt),LocalDateTime.now()));
					return customer;
				}
			}
			else {
				throw new WalletException("Invalid user");
			}
			}
		catch(WalletException ex) {
			System.out.println(ex.getMessage());
		}		
		return null;
				
	}
	@Override
	public CustomerDetails getFundTransfer(Long accnum, Long oaccnum, String pin, String amt) {
		CustomerDetails customer=customerMap.get(accnum);
		CustomerDetails ocustomer=customerMap.get(oaccnum);
		try {
				if(customer==null || ocustomer==null) {
				throw new WalletException("customer with the account number "+accnum+" Not existed");
			}
			if(customer.getAtmPin().equalsIgnoreCase(pin)) {
				if(customer.getBalance() <=Double.parseDouble(amt)) {
					System.out.println("Low Balance");
				}
						
				else {
					double balance=customer.getBalance() - Double.parseDouble(amt);
					customer.setBalance(balance);
					double obalance=ocustomer.getBalance()+Double.parseDouble(amt);
					ocustomer.setBalance(obalance);
					id++;
					transactionMap.put(id,new TransactionDetails(accnum,"Withdraw",Double.parseDouble(amt),LocalDateTime.now()));
					return customer;
				}
			}
			
			else {
				throw new WalletException("Invalid user");
			}
			}
		catch(WalletException ex) {
			System.out.println(ex.getMessage());
		}		
		return null;
	}
	@Override
	public 	boolean getPrintTransactions(Long accnum, String pin) {
	
			try {
				CustomerDetails customer=customerMap.get(accnum);
				
				if(customer==null) {
					throw new WalletException("customer with the account number "+accnum+" Not existed");
				}
				if(!customer.getAtmPin().equalsIgnoreCase(pin)) {
					throw new WalletException("enter correct pin number");
				}
				else {
					for(int key=1;key<=transactionMap.size();key++) {
					TransactionDetails trans=transactionMap.get(key);
					if(trans.getAccnum().compareTo(accnum)==0) {
					System.out.println(trans);
				}
					}
				}
                }
			catch(WalletException ex) {
				System.out.println(ex.getMessage());
			}
			return false;
			
			
}
}
