package com.wallet.service;

import java.util.HashMap;

import com.wallet.bean.CustomerDetails;
import com.wallet.bean.TransactionDetails;
import com.wallet.exception.WalletException;

public interface IWalletService {
	boolean validateEmployee(CustomerDetails cd) throws WalletException;
	Long addCustomer(CustomerDetails cd) throws WalletException;
	boolean validatePin(String string)throws WalletException;
	CustomerDetails getBalance(Long accnum,String pin) throws WalletException;
	CustomerDetails setDeposit(Long accnum, String pin, String amt);
	CustomerDetails getWithdraw(Long accnum, String pin, String amt);
	CustomerDetails getFundTransfer(Long accnum, Long oaccnum, String pin, String amt);
	boolean getPrintTransactions(Long accnum, String pin); 
}
