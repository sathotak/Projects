package com.wallet.bean;

import java.sql.Date;
import java.time.LocalDateTime;

public class TransactionDetails {
private double amount;
private Long accnum;
private int id;
public Long getAccnum() {
	return accnum;
}
public void setAccno(Long accnum) {
	this.accnum = accnum;
}
private String transType;
private LocalDateTime dot;
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public String getTransType() {
	return transType;
}
public void setTransType(String transType) {
	this.transType = transType;
}
public LocalDateTime getDot() {
	return dot;
}
public void setDot(LocalDateTime dot) {
	this.dot = LocalDateTime.now();
}

public TransactionDetails(Long accnum,String transType,double amount, LocalDateTime dot) {
	super();
	this.accnum=accnum;
	this.amount = amount;
	this.transType = transType;
	this.dot = LocalDateTime.now();
}

public TransactionDetails() {
	super();
}
@Override
public String toString() {
	return "Transaction Type=" + transType + ", Amount=" + amount + ", Date "+dot ;
}
}
