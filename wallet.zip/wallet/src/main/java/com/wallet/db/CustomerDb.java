package com.wallet.db;

import java.util.HashMap;

import com.wallet.bean.CustomerDetails;
import com.wallet.bean.TransactionDetails;

public class CustomerDb {
	 private static HashMap<Long,CustomerDetails>
     customerMap=new HashMap<Long,CustomerDetails>();
	 private static HashMap<Integer,TransactionDetails>
     transactionMap=new HashMap<Integer,TransactionDetails>();
static {
	customerMap.put(12345678910L, new CustomerDetails(12345678910L,"Mark","male","23",1244345.44,"Chennai","9996632145","savings","1125"));
	customerMap.put(12345678911L, new CustomerDetails(12345678911L,"Ben","male","35",2343445.33,"Hyderabad","1234567891","Current","2345"));
	customerMap.put(12345678912L, new CustomerDetails(12345678912L,"Anil","male","55",4578.76,"Kerala","9874563217","Savings","4556"));
	customerMap.put(12345678913L, new CustomerDetails(12345678913L,"Pam","male","45",436578.56,"Mumbai","7894561234","Current","9734"));
	customerMap.put(12345678914L, new CustomerDetails(12345678914L,"Sara","male","25",236767.66,"Gao","8794563218","Savings","0725"));
	customerMap.put(12345678915L, new CustomerDetails(12345678915L,"Sunil","male","65",566889.78,"chennai","6547893214","Current","9633"));
}
public static HashMap<Long, CustomerDetails> getCustomerMap() {
	return customerMap;
}
public static HashMap<Integer,TransactionDetails> getTransactionMap() {
	return transactionMap;
}
}
