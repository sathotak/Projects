package org.cap.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cap.dao.IBankDao;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("bankService")
public class BankServiceImpl implements IBankService {
    @Autowired
    private IBankDao bankDao;
	/*@Override
	public void savePilot(Pilot pilot) {
		pilotDao.savePilot(pilot);
		
	}*/
	/*@Override
	public List<Pilot> getAll() {
				return pilotDao.getAll();
	}
	@Override
	public void delete(Integer pilotId) {
		pilotDao.delete(pilotId);
		
	}
	@Override
	public void edit(Pilot pilot1) {
		pilotDao.edit(pilot1);
	}*/
	/*@Override
	public Customer findCustomer(Integer pilotId) {
		// TODO Auto-generated method stub
		return bankDao.findCustomer(pilotId);
	}*/
	@Override
	public boolean validate(int username, String password) {
		// TODO Auto-generated method stub
			return bankDao.validate(username,password);
	}
	@Override
	public void createAccount(Account account) {
		bankDao.createAccount(account);
		
	}
	@Override
	public String getUserName(int customerId) {
		
		return bankDao.getUserName(customerId);
	}
	@Override
	public List<Long> getAccountNumbers() {
		// TODO Auto-generated method stub
		return bankDao.getAccountNumbers();
	}
	@Override
	public void depWithAccount(Transaction transaction) {
		bankDao.depWithAccount(transaction);
		
	}
	@Override
	public List<Account> getAllAccounts(int customerId) {
		
		return bankDao.getAllAccounts(customerId);
	}
	@Override
	public List<Account> getAccountWithBalance(int custId){
		
		String str="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='debit'";
				Map<Account, Double> deMap = bankDao.getAmoutCrDe(str,custId);
		
			String str1="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='credit'";
			Map<Account, Double> crMap = bankDao.getAmoutCrDe(str1,custId);
				

			List<Account> accounts=getAllAccounts(custId);
			
			/*ArrayList<Account> accounts=new ArrayList<>();
			for(Account account:accounts1) {
				Account account1=new Account();
				
				account1.setAccountId(account.getAccountId());
				account1.setAccountNo(account.getAccountNo());
				account1.setAccountType(account.getAccountType());
				account1.setOpeningBalance(account.getOpeningBalance());
				account1.setOpeningDate(account.getOpeningDate());
				account1.setStatus(account.getStatus());
				
				accounts.add(account);
			}*/
			
			Iterator<Account> iterator= accounts.iterator();
			while(iterator.hasNext()) {
				Account account=iterator.next();
				double balance=0;
				double crAmt=0,deAmt=0;
				account.setUpdateBalance(0);
				
				if(crMap.get(account) ==null)
					crAmt=0;
				else
					crAmt=crMap.get(account);
				

				if( deMap.get(account) ==null)
					deAmt=0;
				else
					deAmt= deMap.get(account);
				
				
				
				balance=account.getOpeningBalance() +
						crAmt-deAmt;
				
				account.setUpdateBalance(balance);
				
			}
			
			
			return accounts;
			
			
	}
}
