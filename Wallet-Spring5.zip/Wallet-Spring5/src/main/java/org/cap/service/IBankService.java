package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;



public interface IBankService {
//	public  void savePilot(Pilot pilot);
	/* public List<Pilot> getAll();
	public void delete(Integer pilotId);
	public void edit(Pilot pilot1);
*/
	public boolean validate(int userName, String password);

	public void createAccount(Account account);

	public String getUserName(int customerId);

	public List<Long> getAccountNumbers();

	public void depWithAccount(Transaction transaction);
	
	
	
	public List<Account> getAllAccounts(int customerId);
	public	List<Account> getAccountWithBalance(int custId);

	//public Customer findCustomer(Integer customerId);
}
