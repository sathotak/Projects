package org.cap.dao;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("bankDao")
@Transactional
public class BankDaoImpl implements IBankDao {
	@PersistenceContext
private EntityManager entityManager;
	private Customer user;
	/*@Transactional
	@Override
	public void savePilot(Pilot pilot) {
		entityManager.persist(pilot);		
	}*/
	/*@Transactional(readOnly=true)
	@Override
	public List<Pilot> getAll() {
		List<Pilot> pilots=entityManager.createQuery("from Pilot").getResultList(); 
		//class name pilot
		return pilots;
	}
	@Transactional
	@Override
	public void delete(Integer pilotId) {
		Pilot pilot= entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
			}
	@Transactional
	@Override
	public void edit(Pilot pilot) 
     {
		Integer pilotId=pilot.getPilotId();
		Pilot pilot1= entityManager.find(Pilot.class, pilotId);

		if(pilot1==null)
		{
			entityManager.persist(pilot);
		}
		else {
			entityManager.merge(pilot);	
		}
	}*/
	/*@Transactional
	@Override
	public Customer findCustomer(Integer customerId) {
		Customer customer=entityManager.find(Customer.class, customerId);
		//entityManager.remove(pilot);
		return customer;
	}*/
	@Transactional
	@Override
	public boolean validate(int username, String password) {
		
		user=entityManager.find(Customer.class, username);
		if(user!=null)
		if(username==(user.getCustomerId()) && password.equals(user.getCustomerPwd())) {
			return true;
		}
		return false;
		}
	@Transactional
	@Override
	public void createAccount(Account account) {
		account.setOpeningDate(new Date());
		account.setStatus("Active");
		account.setCustomer(user);
        Query query= entityManager.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		entityManager.persist(account);
	}
	
	@Override
	public String getUserName(int customerId) {
		if(user!=null) {
				return user.getFirstName();
			}
			return null;
			
	}
	@Transactional(readOnly=true)
	@Override
	public List<Long> getAccountNumbers() {
		Query query=entityManager.createQuery("select accountNo from Account where customerId=:custId");
		query.setParameter("custId", user.getCustomerId());
		List<Long> accountNos= query.getResultList();
		return accountNos;
	}
	@Transactional
	@Override
	public void depWithAccount(Transaction transaction) {
		transaction.setCustomer(user);
		transaction.setStatus("Completed");
		transaction.setTransactionDate(new Date());
	entityManager.persist(transaction);
		
	}
	@Transactional(readOnly=true)
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId){
	
		
		Query query2=entityManager
				.createQuery(strQuery);
		
		query2.setParameter("custId", customerId);
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount))
				);
		return map;
	}
	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAccounts(int customerId) {
		
		Query query= entityManager
			.createQuery("from Account acc where acc.customer.customerId=:custId");
		
		query.setParameter("custId", customerId);
		
		
		List<Account> accounts= query.getResultList();
		
		
		return accounts;
	}
	
}
	


